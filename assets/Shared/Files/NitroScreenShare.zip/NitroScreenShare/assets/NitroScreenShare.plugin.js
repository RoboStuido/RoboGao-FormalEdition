/**
 * @name NitroScreenShare
 * @author RoboStudio
 * @version 1.0.0
 * @description Unlock nitro screen share
 */

module.exports = class NitroScreenShare {
    load() {
        this.start();
    } // Optional function, when the plugin is loaded.

    start() {
        this.backup = BdApi.findModuleByProps("getCurrentUser").getCurrentUser().premiumType; // Backup the current premium type.
        BdApi.findModuleByProps("getCurrentUser").getCurrentUser().premiumType = 2; // Set the premium type to Nitro.
    } // Required function, when the plugin is enabled.

    stop() {
        BdApi.findModuleByProps("getCurrentUser").getCurrentUser().premiumType = this.backup; // Restore the premium type.
    } // Required function, when the plugin is disabled.
}